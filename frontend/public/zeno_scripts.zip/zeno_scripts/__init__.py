"""A package for analyzing chatbot results."""
